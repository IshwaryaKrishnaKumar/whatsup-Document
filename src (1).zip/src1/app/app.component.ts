import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  employees = [
    {ecode:"23.2512", fName:"Rohit kumar", lName:"Verma", dob:"1/1/1990"},
    {ecode:"12.3327", fName:"Raj singh", lName:"sharma", dob:"1/1/1991"},
    {ecode:"12.3412", fName:"Mohit", lName:"xyx", dob:"1/1/1992"},
    {ecode:"45.2312", fName:"Arun", lName:"abc", dob:"1/1/1993"},
  ]

}
