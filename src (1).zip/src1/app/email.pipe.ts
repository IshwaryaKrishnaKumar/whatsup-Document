import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'email'
})
export class EmailPipe implements PipeTransform {
  emailId = ""

  transform(value: string, value2: string): unknown {
    this.emailId = value2 + '@marug.com'; 
    this.emailId = value + this.emailId;
    return this.emailId;
  }

}
